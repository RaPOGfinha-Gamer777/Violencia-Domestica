using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayWin : MonoBehaviour
{
    public AudioSource audioSource;
    public AudioClip winAudio;

    private void OnEnable()
    {
        audioSource.clip = winAudio;
        audioSource.Play();
    }
}
