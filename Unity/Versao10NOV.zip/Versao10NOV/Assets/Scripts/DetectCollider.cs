using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DetectCollider : MonoBehaviour
{
    private GameController gameController;
    private float playerStrength;
    private string tagString = "Vazio";

    public List<GameObject> enemiesInRange;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        playerStrength = gameController.playerStrenght;
    }

    private void Update()
    {
        Attack();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        tagString = collision.gameObject.tag;

        if (tagString.Contains("Enemy"))
        {
            enemiesInRange.Add(collision.gameObject);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        tagString = "Vazio";
        enemiesInRange.Remove(collision.gameObject);
    }


    

    float elapsedTime = 1000.0f;
    [Range(0.0f, 3.0f)]
    public float punshTime = 1.0f;
    int punshCount;
    [Range(0.0f, 2.0f)]
    public float hardDif = 0.3f;

    void Attack()
    {
        elapsedTime += Time.deltaTime;

        if (elapsedTime > (punshTime * 3) + hardDif)
            punshCount = 0;


        if (this.gameObject.name == "AttackColliderOne")
        {
            float targetTime = (punshCount > 1 ? punshTime + hardDif : punshTime);
            if ((Input.GetKeyDown(KeyCode.R) || Input.GetButtonDown("VERDE0")) && elapsedTime >= targetTime)
            {
                elapsedTime = 0.0f;
                punshCount++;
                if (punshCount == 4)
                {
                    punshCount = 0;                    
                }

                // ANIMA��O DE SOCO OU CHUTE

                //Debug.Log("JOGADOR 1 ATACOU: " + tagString);

                foreach (GameObject enemy in enemiesInRange)
                {
                    EnemyStats enemyScript = enemy.GetComponent<EnemyStats>();

                    if (enemyScript != null)
                    {
                        enemyScript.TakingDamage(playerStrength);
                    }
                }
            }
        }


        else if (this.gameObject.name == "AttackColliderTwo")
        {

            float targetTime = (punshCount > 1 ? punshTime + hardDif : punshTime);

            if ((Input.GetKeyDown(KeyCode.O) || Input.GetButtonDown("VERDE1")) && elapsedTime >= targetTime)
            {
                elapsedTime = 0.0f;
                punshCount++;
                if (punshCount == 4)
                {
                    punshCount = 0;
                }

                // ANIMA��O DE SOCO OU CHUTE

                //Debug.Log("JOGADOR 2 ATACOU: " + tagString);

                foreach (GameObject enemy in enemiesInRange)
                {
                    EnemyStats scriptInimigo = enemy.GetComponent<EnemyStats>();

                    if (scriptInimigo != null)
                    {
                        scriptInimigo.TakingDamage(playerStrength);
                    }
                }
            }
        }
    }
}
