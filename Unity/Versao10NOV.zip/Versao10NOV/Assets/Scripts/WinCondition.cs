using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WinCondition : MonoBehaviour
{
    public bool bossEntranceBool;

    public GameObject winScreen;
    public GameObject defeatScreen;

    public GameObject playerOne;
    public GameObject playerTwo;

    private void Update()
    {
        CheckWinCondition();
        CheckDefeatCondition();

        ReturnToMenu();
    }

    void CheckDefeatCondition()
    {
        if (!playerOne.activeSelf && !playerTwo.activeSelf)
        {
            Time.timeScale = 0;
            defeatScreen.SetActive(true);
        }
    }

    void CheckWinCondition()
    {
        GameObject enemy = GameObject.FindWithTag("RegularEnemy");
        
        if (enemy == null)
        {
            bossEntranceBool = true;
        }
    }

    void ReturnToMenu()
    {
        if (winScreen.activeSelf || defeatScreen.activeSelf)
        {
            if (Input.anyKeyDown)
            {
                SceneManager.LoadScene("MenuPrincipal");
            }
        }
    }
}
