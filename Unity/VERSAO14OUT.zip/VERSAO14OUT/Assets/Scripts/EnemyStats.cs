using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class EnemyStats : MonoBehaviour
{
    public float health;
    private GameController gameController;

    private SpriteRenderer spriteRenderer;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        
        if (this.gameObject.name.Contains("Regular")) health = gameController.regularHP;

        else if (this.gameObject.name.Contains("Buffed")) health = gameController.buffedHP;

        else if (this.gameObject.name.Contains("Boss")) health = gameController.bossHP;
    }

    public void TakingDamage(float damage)
    {
        health -= damage;
        if (health <= 0)
        {
            // ANIMA��O DE MORTE
            Invoke(nameof(Die), 0.1f); // TEMPO QUE DURAR A ANIMA��O
        }
        GiveFeedback();
    }

    private void Die()
    {
        gameObject.transform.position = new Vector2(0, 10);
        Destroy(gameObject, 0.2f);
    }

    void GiveFeedback()
    {
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        spriteRenderer.color = Color.red;

        Invoke(nameof(ResetSpriteRender), 0.15f);
    }

    void ResetSpriteRender()
    {
        spriteRenderer.color = Color.white;
    }
}
