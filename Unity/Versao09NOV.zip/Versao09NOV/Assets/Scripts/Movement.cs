using System.Collections;
using System.Collections.Generic;
using System.Net.Http.Headers;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public Rigidbody2D playerOneBody;
    public Rigidbody2D playerTwoBody;
    public bool isWalking = false;

    private float moveSpeed;

    private GameController gameController;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        moveSpeed = gameController.playerSpeed;
    }

    void Update()
    {
        MovePlayerOne();
        MovePlayerTwo();
    }

    void MovePlayerOne()
    {
        float horizontalOne = Input.GetAxis("HORIZONTAL0");
        float verticalOne = Input.GetAxis("VERTICAL0");

        playerOneBody.velocity = new Vector2(horizontalOne, verticalOne) * moveSpeed;

        if (moveSpeed != 0)
        {
            isWalking = true;
        }
        else
        {
            isWalking = false;
        }
        // ANIMA��O DE CORRER
        if (isWalking == true)
        {
            
        }
        
    }
    void MovePlayerTwo()
    {
        float horizontalTwo = Input.GetAxis("HORIZONTAL1");
        float verticalTwo = Input.GetAxis("VERTICAL1");

        playerTwoBody.velocity = new Vector2(horizontalTwo, verticalTwo) * moveSpeed;

        if (moveSpeed != 0)
        {
            isWalking = true;
        }
        else
        {
            isWalking = false;
        }

        // ANIMA��O DE CORRER
    }
   
}
