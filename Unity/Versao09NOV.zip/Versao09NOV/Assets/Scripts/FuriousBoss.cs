using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FuriousBoss : MonoBehaviour
{
    public float strengthMultiplier = 1;
    public float ratioMultiplier = 1;

    private SpriteRenderer spriteRenderer;

    private EnemyStats enemyStats;

    private void Start()
    {
        enemyStats = GameObject.FindAnyObjectByType<EnemyStats>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        if (enemyStats.health <= 15)
        {
            GetFurious();
        }
    }

    void GetFurious()
    {
        strengthMultiplier = 2;
        ratioMultiplier = 2.5f;

        spriteRenderer.color = Color.magenta;
    }   
}
