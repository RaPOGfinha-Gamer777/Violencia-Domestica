using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    [Header ("Player Stats")]
    public float playerTotalHP;
    public float playerStrenght;
    public float playerSpeed;

    [Header("Enemies Stats")]
    public float regularHP;
    public float regularStrenght;
    public float regularSpeed;
    public float regularRatio;

    public float buffedHP;
    public float buffedStrenght;
    public float buffedRatio;

    public float bossHP;
    public float bossStrenght;
    public float bossRatio;
    public float bossSpeed;

    [Header("General Controller")]
    public int amountOfEnemies;
    public float resurrectTimer;

    [Header("Player Select")]
    public int characterIndex;
}
