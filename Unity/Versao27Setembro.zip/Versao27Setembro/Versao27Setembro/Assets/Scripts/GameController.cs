using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    [Header ("Player Stats")]
    public float playerTotalHP;
    public float playerStrenght;
    public float playerSpeed;

    [Header("Enemies Stats")]
    public float regularHP;
    public float regularStrenght;
    public float regularSpeed;
    public float regularRatio;

    [Header("General Controller")]
    public int amountOfEnemies;

    [Header("Player Select")]
    public int characterIndex;
}
