using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossMovement : MonoBehaviour
{
    private GameController gameController;
    public EnemyAttack enemyAttack;

    public Transform playerOne;
    public Transform playerTwo;

    public bool moveBossBool;

    private float speed;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        speed = gameController.bossSpeed;

        Invoke(nameof(AlternateBossMoveBool), 3);
    }

    void Update()
    {
        if (enemyAttack.moveBool & moveBossBool)
        {
            CalculatePlayersDistance();
        }
    }

    void AlternateBossMoveBool()
    {
        moveBossBool = !moveBossBool;
    }

    void CalculatePlayersDistance()
    {
        float distanceToPlayer1 = Vector3.Distance(transform.position, playerOne.position);
        float distanceToPlayer2 = Vector3.Distance(transform.position, playerTwo.position);

        Transform nearestPlayer = (distanceToPlayer1 < distanceToPlayer2) ? playerOne : playerTwo;

        MoveTowards(nearestPlayer);
    }

    void MoveTowards(Transform target)
    {
        Vector3 direction = (target.position - transform.position).normalized;

        transform.position += direction * speed * Time.deltaTime;
    }
}
