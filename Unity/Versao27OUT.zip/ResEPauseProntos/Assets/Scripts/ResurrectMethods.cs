using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResurrectMethods : MonoBehaviour
{
    private PlayerHP playerHP;

    public float resTimerMultiplier;

    public GameObject playerOne;
    public GameObject playerTwo;

    private void Start()
    {
        playerHP = GameObject.FindAnyObjectByType<PlayerHP>();
    }

    public void ResPlayerOne()
    {
        playerOne.SetActive(true);
    }

    public void ResPlayerTwo()
    {
        playerTwo.SetActive(true);
    }
}
