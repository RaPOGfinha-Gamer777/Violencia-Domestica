using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class EnemyAttack : MonoBehaviour
{
    private float strenght;
    public bool moveBool = true;
    private float attackTimer;
    private float attackRatio;

    private GameController gameController;

    private GameObject attackTarget;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();

        if (this.gameObject.transform.parent.name.Contains("Regular"))
        {
            strenght = gameController.regularStrenght;
            attackRatio = gameController.regularRatio;
        }

        else if (this.gameObject.transform.parent.name.Contains("Buffed"))
        {
            strenght = gameController.buffedStrenght;
            attackRatio = gameController.buffedRatio;
        }

        else if (this.gameObject.transform.parent.name.Contains("Boss"))
        {
            strenght = gameController.bossStrenght;
            attackRatio = gameController.bossRatio;
        }
    }

    private void Update()
    {
        if (attackTarget != null)
        {
            attackTimer += Time.deltaTime;

            if (attackTimer >= attackRatio)
            {
                Attack();
                attackTimer = 0;
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "HitBox")
        {
            moveBool = false;
            attackTarget = collision.gameObject;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        moveBool = true;
        attackTarget = null;
        attackTimer = 0;
    }

    void Attack()
    {
        if (attackTarget != null)
        {
            PlayerHP playerHP = attackTarget.GetComponent<PlayerHP>();

            if (playerHP != null)
            {
                playerHP.TakingDamage(strenght);
                Debug.Log("ATACANDO " + attackTarget.transform.parent.name);
            }
        }
    }
}
