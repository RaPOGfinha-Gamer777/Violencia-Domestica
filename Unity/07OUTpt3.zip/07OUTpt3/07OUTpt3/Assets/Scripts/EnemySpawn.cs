using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawn : MonoBehaviour
{
    public GameObject enemyPrefab;
    public GameObject buffedEnemyPrefab;

    public GameObject[] spawnPoints;
    public GameObject[] buffedSpawnPoints;

    private int amount;
    public float spawnRadius = 0.5f;

    private GameController gameController;

    void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        amount = gameController.amountOfEnemies;

        SpawnEnemies();
        SpawnBuffedEnemies();
    }

    void SpawnEnemies()
    {
        for (int x = 0; x < spawnPoints.Length; x++)
        {
            for (int i = 0; i < amount; i++)
            {
                Vector2 randomPos = Random.insideUnitCircle * spawnRadius;
                Vector3 newPos = new Vector3(randomPos.x, randomPos.y, 0) + spawnPoints[x].transform.position;

                GameObject newEnemy = Instantiate(enemyPrefab, newPos, Quaternion.identity);
            }
        }
    }

    void SpawnBuffedEnemies()
    {
        for (int x = 0; x < buffedSpawnPoints.Length; x++)
        {
            for (int i = 0; i < amount; i++)
            {
                Vector2 randomPos = Random.insideUnitCircle * spawnRadius;
                Vector3 newPos = new Vector3(randomPos.x, randomPos.y, 0) + buffedSpawnPoints[x].transform.position;

                GameObject newEnemy = Instantiate(buffedEnemyPrefab, newPos, Quaternion.identity);
            }
        }
    }
}
