using System.Collections;
using System.Collections.Generic;
using System.Net.Http.Headers;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public Rigidbody2D playerOneBody;
    public Rigidbody2D playerTwoBody;
    public Animator playerOneAnimator;
    public Animator playerTwoAnimator;
    public bool isPlayerOneWalking = false;
    public bool isPlayerTwoWalking = false;

    private float moveSpeed;

    private GameController gameController;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        moveSpeed = gameController.playerSpeed;
    }

    void Update()
    {
        MovePlayerOne();
        MovePlayerTwo();
    }

    void MovePlayerOne()
    {
        float horizontalOne = Input.GetAxis("HORIZONTAL0");
        float verticalOne = Input.GetAxis("VERTICAL0");

        playerOneBody.velocity = new Vector2(horizontalOne, verticalOne) * moveSpeed;

        if (playerOneBody.velocity.magnitude > 0)
        {
            isPlayerOneWalking = true;
        }
        else
        {
            isPlayerOneWalking = false;
        }
        // ANIMA��O DE CORRER
        playerOneAnimator.SetBool("Andar", isPlayerOneWalking);
    }
    void MovePlayerTwo()
    {
        float horizontalTwo = Input.GetAxis("HORIZONTAL1");
        float verticalTwo = Input.GetAxis("VERTICAL1");

        playerTwoBody.velocity = new Vector2(horizontalTwo, verticalTwo) * moveSpeed;

        if (playerTwoBody.velocity.magnitude > 0)
        {
            isPlayerTwoWalking = true;
        }
        else
        {
            isPlayerTwoWalking = false;
        }
        // ANIMA��O DE CORRER
        playerTwoAnimator.SetBool("Andar", isPlayerTwoWalking);
        
    }
   
}
