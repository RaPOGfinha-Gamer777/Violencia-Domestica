using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class MuteManager : MonoBehaviour
{
    public KeyCode muteKey1 = KeyCode.G;
    public KeyCode muteKey2 = KeyCode.K;

    private bool isMuted = false;
    void Update()
    {
        
        if (Input.GetKeyDown(muteKey1) || Input.GetKeyDown(muteKey2))
        {
            isMuted = !isMuted;

            AudioListener.pause = isMuted;

            Debug.Log(isMuted ? "Audio Muted" : "Audio Unmuted");
        }
    }
}
    
    


