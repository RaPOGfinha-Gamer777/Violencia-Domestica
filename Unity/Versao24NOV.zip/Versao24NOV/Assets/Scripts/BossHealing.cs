using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class BossHealing : MonoBehaviour
{
    private EnemyStats enemyStats;
    private BossMovement bossMovement;

    private SpriteRenderer spriteRenderer;

    private float healTimer = 0;
    private Animator enemyAnimator;

    public AudioSource audioSource;

    private void Start()
    {
        enemyStats = GameObject.FindAnyObjectByType<EnemyStats>();
        bossMovement = GameObject.FindAnyObjectByType<BossMovement>();
        spriteRenderer = GetComponent<SpriteRenderer>();

        enemyAnimator = GetComponent<Animator>();
    }

    private void Update()
    {
        if (enemyStats.health <= 25 && enemyStats.health >= 5)
        {
            CheckBossHP();
        }
    }

    void CheckBossHP()
    {
        healTimer += Time.deltaTime;

        if (healTimer > 3.5)
        {
            healTimer = 0;

            int rng = Random.Range(0, 3);
            
            if (rng == 0)
            {
                enemyAnimator.Play("CuraBoss");

                Invoke(nameof(HealBoss), 3);
            }
        }
    }

    void HealBoss()
    {
        enemyStats.health += 5;

        audioSource.Play();
    }
}
