using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class BossMovement : MonoBehaviour
{
    private GameController gameController;
    public EnemyAttack enemyAttack;
    private Animator enemyAnimator;

    public Transform playerOne;
    public Transform playerTwo;

    public bool moveBossBool;
    private float timer = 3f;
    private float speed;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        speed = gameController.bossSpeed;

        

        enemyAnimator = transform.GetComponent<Animator>();

    }

    void Update()
    {
        timer -= Time.deltaTime;
        if (timer < 0 && !moveBossBool)
        {
            moveBossBool = true;
            //Animacao Andar
            enemyAnimator.SetBool("Andar", true);
        }
        if (enemyAttack.moveBool && moveBossBool)
        {
            CalculatePlayersDistance();
        }
    }

    void AlternateBossMoveBool()
    {
        
    }

    void CalculatePlayersDistance()
    {
        float distanceToPlayer1 = Vector3.Distance(transform.position, playerOne.position);
        float distanceToPlayer2 = Vector3.Distance(transform.position, playerTwo.position);

        Transform nearestPlayer = (distanceToPlayer1 < distanceToPlayer2) ? playerOne : playerTwo;

        MoveTowards(nearestPlayer);
    }

    void MoveTowards(Transform target)
    {
        Vector3 direction = (target.position - transform.position).normalized;

        transform.position += direction * speed * Time.deltaTime;

        
    }
    
    

}
