using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Resurrect : MonoBehaviour
{
    private GameController gameController;

    private bool resBool;
    private float multiplier;
    private float timerBarX;

    private float timeToRes;
    private float timeProportion;

    private GameObject timerBar;
    private GameObject resBar;

    private GameObject nearestPlayer;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        timeToRes = gameController.resurrectTimer;

        timerBarX = timerBar.transform.localScale.x;
        timeProportion = timerBarX/timeToRes;
    }

    private void Update()
    {
        if (resBool)
        {
            CalculateResTimer();
        }

        if (nearestPlayer != null)
        {
            if (nearestPlayer.transform.parent.name == "PlayerOne")
            {
                if (Input.GetKeyDown(KeyCode.T) || Input.GetButtonDown("VERMELHO0"))
                {
                    resBar.transform.localScale = new Vector2(resBar.transform.localScale.x + 0.25f, resBar.transform.localScale.y);

                    if (resBar.transform.localScale.x >= 3)
                    {
                        ResurrectMethods resurrectMethods = FindAnyObjectByType<ResurrectMethods>();
                        resurrectMethods.ResPlayerTwo();

                        resurrectMethods.playerTwo.transform.position = resBar.transform.parent.position;
                        Destroy(gameObject);
                    }
                }
            }

            else if (nearestPlayer.transform.parent.name == "PlayerTwo")
            {
                if (Input.GetKeyDown(KeyCode.I) || Input.GetButtonDown("VERMELHO1"))
                {
                    resBar.transform.localScale = new Vector2(resBar.transform.localScale.x + 0.25f, resBar.transform.localScale.y);

                    if (resBar.transform.localScale.x >= 3)
                    {
                        ResurrectMethods resurrectMethods = FindAnyObjectByType<ResurrectMethods>();
                        resurrectMethods.ResPlayerOne();

                        resurrectMethods.playerOne.transform.position = resBar.transform.parent.position;
                        Destroy(gameObject);
                    }
                }
            }
        }
    }

    private void OnEnable()
    {
        resBool = true;
        timerBar = transform.Find("TimerSprite").gameObject;
        resBar = transform.Find("ResSprite").gameObject;

        ResurrectMethods resurrectMethods = GameObject.FindObjectOfType<ResurrectMethods>();
        multiplier = resurrectMethods.resTimerMultiplier;
    }

    void CalculateResTimer()
    {
        timerBarX -= Time.deltaTime * multiplier * timeProportion;

        timerBar.transform.localScale = new Vector2(timerBarX, timerBar.transform.localScale.y);

        if (timerBarX < 0)
        {
            Die();
        }
    }

    void Die()
    {
        ResurrectMethods resurrectMethods = FindAnyObjectByType<ResurrectMethods>();
        resurrectMethods.PlayDeathAudio();

        Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "HitBox")
        {
            nearestPlayer = collision.gameObject;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "HitBox")
        {
            nearestPlayer = null;
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "HitBox")
        {
            nearestPlayer = collision.gameObject;
        }
    }
}
