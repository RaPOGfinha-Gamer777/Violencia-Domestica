using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.UI;

public class PlayerData : MonoBehaviour
{
    public GameObject playerOne;
    public GameObject playerTwo;
    public Slider player1Hp;
    public Slider player2Hp;
    
    private void OnEnable()
    {
        if (Data.instance.enableOnePlayer)
        {
            playerOne.SetActive(true);
            playerTwo.SetActive(false);

            GameController gameController = FindAnyObjectByType<GameController>();
            gameController.amountOfEnemies = 1;
            gameController.playerTotalHP = 20;
            player1Hp.maxValue = gameController.playerTotalHP;
            player1Hp.value = player1Hp.maxValue;

        }
        else if (Data.instance.enableTwoPlayers)
        {
            playerOne.SetActive(true);
            playerTwo.SetActive(true);

            GameController gameController = FindAnyObjectByType<GameController>();
            gameController.amountOfEnemies = 2;
            gameController.playerTotalHP = 10;
            player1Hp.maxValue = gameController.playerTotalHP;
            player2Hp.maxValue = gameController.playerTotalHP;
            player1Hp.value = player1Hp.maxValue;
            player2Hp.value = player2Hp.maxValue;
        }
    }
}
