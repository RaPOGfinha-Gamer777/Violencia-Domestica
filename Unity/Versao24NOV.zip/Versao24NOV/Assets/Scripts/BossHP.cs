using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class BossHP : MonoBehaviour
{
    private EnemyStats enemyStats;
    public GameObject winScreen;
    public TextMeshProUGUI bossHPText;
    public Slider barraVidaBoss;
    private void Start()
    {
        enemyStats = GameObject.FindAnyObjectByType<EnemyStats>();
        barraVidaBoss.maxValue = 35;
    }

    private void Update()
    {
        if (gameObject.activeSelf)
        {
            barraVidaBoss.value = enemyStats.health;

            if (enemyStats.health <= 0)
            {
                winScreen.SetActive(true);
            }
        }
    }
}
