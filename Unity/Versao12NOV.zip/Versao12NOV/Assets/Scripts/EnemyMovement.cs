using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    private GameController gameController;
    public EnemyAttack enemyAttack;
    private float enemySpeed;

    private Animator enemyAnimator;
    
    public GameObject enemyObj;
    public GameObject target;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        enemySpeed = gameController.regularSpeed;
        enemyAnimator = transform.parent.GetComponent<Animator>();
    }

    private void Update()
    {
        if (target != null && enemyAttack.moveBool)
        {
            Transform destination = target.transform;
            Vector2 direction = destination.position - transform.position;

            direction.Normalize();

            enemyObj.transform.position = transform.position + (Vector3)direction * enemySpeed * Time.deltaTime;

            //Animacao inimigo
            enemyAnimator.SetBool("Andar", true);
        }
        else
        {
            enemyAnimator.SetBool("Andar", false);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            target = collision.gameObject;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag != "Player")
        {
            target = null;
        }
    }
}
