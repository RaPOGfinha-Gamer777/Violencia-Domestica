using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Unity.VisualScripting;
using UnityEngine.UIElements;

public class PlayerHP : MonoBehaviour
{
    public float health;
    private GameController gameController;

    public GameObject faintedOnePrefab;
    public GameObject faintedTwoPrefab;

    public float oneHP;
    public float twoHP;

    public TextMeshProUGUI textOne;
    public TextMeshProUGUI textTwo;

    private SpriteRenderer spriteRenderer;

    public AudioSource hitAudioSource;
    public AudioSource koAudioSource;

    public AudioClip koAudio;
    public AudioClip deathAudio;

    private bool canRes;

    void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        health = gameController.playerTotalHP;

        Transform parentTransform = transform.parent;
        spriteRenderer = parentTransform.GetComponent<SpriteRenderer>();

        UpdateUIText();
    }

    public void TakingDamage(float damage)
    {
        health -= damage;

        hitAudioSource.Play();

        UpdateUIText();

        if (health <= 0)
        {
            if (gameObject.transform.parent.name == "PlayerOne")
            {
                Vector3 playerPos = gameObject.transform.parent.position;
                GameObject faintedPlayer = Instantiate(faintedOnePrefab, playerPos, Quaternion.identity);
            }

            else if (gameObject.transform.parent.name == "PlayerTwo")
            {
                Vector3 playerPos = gameObject.transform.parent.position;
                GameObject faintedPlayer = Instantiate(faintedTwoPrefab, playerPos, Quaternion.identity);
            }

            Invoke(nameof(Faint), 0.1f);
        }

        GiveFeedback();
    }

    void UpdateUIText()
    {
        if (gameObject.transform.parent.name == "PlayerOne")
        {
            textOne.text = "Player 1:  " + health.ToString();
            oneHP = health;
        }

        else if (gameObject.transform.parent.name == "PlayerTwo")
        {
            textTwo.text = "Player 2:  " + health.ToString();
            twoHP = health;
        }
    }

    void Faint()
    {
        koAudioSource.clip = koAudio;
        koAudioSource.Play();

        transform.parent.gameObject.SetActive(false);
        transform.parent.position = new Vector3(100, 20, 0);

        ResurrectMethods resurrectMethods = GameObject.FindObjectOfType<ResurrectMethods>();
        resurrectMethods.resTimerMultiplier += 0.75f;
    }

    void GiveFeedback()
    {
        spriteRenderer.color = Color.red;

        Invoke(nameof(ResetSpriteRender), 0.15f);
    }

    void ResetSpriteRender()
    {
        spriteRenderer.color = Color.white;
    }

    private void OnEnable()
    {
        if (canRes)
        {
            health = 5;
            UpdateUIText();
        }
    }

    private void OnDisable()
    {
        canRes = true;
    }
}
