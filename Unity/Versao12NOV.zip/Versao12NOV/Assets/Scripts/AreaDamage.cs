using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AreaDamage : MonoBehaviour
{
    public float areaAttackTimer;
    private bool areaAttackBool = true;

    public GameObject areaElipse;

    public List<GameObject> playersInRange;

    private BossMovement bossMovement;

    public AudioSource audioSource;
    public AudioClip chargingAudio;
    public AudioClip attackAudio;

    private void Start()
    {
        bossMovement = GameObject.FindAnyObjectByType<BossMovement>();
    }

    private void Update()
    {
        if (areaAttackBool && playersInRange.Count > 0)
        {
            areaAttackTimer += Time.deltaTime;

            if (areaAttackTimer > 4.5)
            {
                bossMovement.moveBossBool = false;
                areaAttackBool = false;
                areaAttackTimer = 0;

                audioSource.clip = chargingAudio;
                audioSource.Play();

                Invoke(nameof(AttackPlayersArround), 2);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "HitBox")
        {
            playersInRange.Add(collision.gameObject);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "HitBox")
        {
            playersInRange.Remove(collision.gameObject);

            if (playersInRange.Count == 0)
            {
                areaAttackTimer = 0;
            }
        }
    }

    void AttackPlayersArround()
    {
        areaElipse.SetActive(true);

        audioSource.clip = attackAudio;
        audioSource.Play();

        foreach (GameObject player in playersInRange)
        {
            PlayerHP playerScript = player.GetComponent<PlayerHP>();

            if (playerScript != null)
            {
                playerScript.TakingDamage(2);
            }
            else Debug.Log("paia");
        }

        Invoke(nameof(ResetElipseSprite), 0.25f);
        Invoke(nameof(ResetAreaAttack), 0.75f);
    }

    void ResetElipseSprite()
    { 
        areaElipse.SetActive(false);
    }

    private void ResetAreaAttack()
    {
        bossMovement.moveBossBool = true;
        areaAttackBool = true;
    }
}
