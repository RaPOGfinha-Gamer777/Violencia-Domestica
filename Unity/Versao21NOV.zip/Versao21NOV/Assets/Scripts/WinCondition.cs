using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WinCondition : MonoBehaviour
{
    public bool bossEntranceBool;

    public GameObject winScreen;
    public GameObject defeatScreen;

    public GameObject houseText;

    public GameObject playerOne;
    public GameObject playerTwo;

    public GameObject boss;

    private bool menuBool;
    private float menuTimer;

    private void Update()
    {
        CheckWinCondition();
        CheckDefeatCondition();

        if (winScreen.activeSelf || defeatScreen.activeSelf)
        {
            menuTimer += Time.deltaTime;
            if (menuTimer > 2) menuBool = true;

            if (Input.anyKeyDown && menuBool)
            {
                SceneManager.LoadScene("MenuPrincipal");
            }
        }
    }

    void CheckDefeatCondition()
    {
        if (!playerOne.activeSelf && !playerTwo.activeSelf)
        {
            defeatScreen.SetActive(true);
        }
    }

    void CheckWinCondition()
    {
        GameObject enemy = GameObject.FindWithTag("RegularEnemy");
        
        if (enemy == null)
        {
            bossEntranceBool = true;
            houseText.SetActive(true);
        }

        if (boss != null)
        {
            if (boss.activeSelf) houseText.SetActive(false);
        }
    }
}
