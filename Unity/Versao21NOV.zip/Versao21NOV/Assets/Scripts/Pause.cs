using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Pause : MonoBehaviour
{
    public GameObject pauseScreen;

    public AudioSource audioSource;
    public AudioClip startAudio;

    private void Start()
    {
        Time.timeScale = 0;
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.Alpha1) || Input.GetButtonDown("MENU"))
        {
            CancelInvoke();

            if (pauseScreen.activeSelf)
            {
                pauseScreen.SetActive(false);
                Time.timeScale = 1;

                audioSource.clip = startAudio;
                audioSource.Play();
            }
            else
            {
                pauseScreen.SetActive(true);
                Time.timeScale = 0;
            }
        }

        if (Input.GetKeyDown(KeyCode.Y) || Input.GetKeyDown(KeyCode.U) || Input.GetButtonDown("PRETO0") || Input.GetButtonDown("PRETO1"))
        {
            if (pauseScreen.activeSelf)
            {
                SceneManager.LoadScene("MenuPrincipal");
            }
        }
    }
}
