using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayDefeat : MonoBehaviour
{
    public AudioSource audioSource;
    public AudioClip defeatAudio;

    private void OnEnable()
    {
        audioSource.clip = defeatAudio;
        audioSource.Play();
    }
}
