using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Unity.VisualScripting;
using UnityEngine.UIElements;

public class PlayerHP : MonoBehaviour
{
    public float health;
    private GameController gameController;

    public float oneHP;
    public float twoHP;

    public TextMeshProUGUI textOne;
    public TextMeshProUGUI textTwo;

    private SpriteRenderer spriteRenderer;

    void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        health = gameController.playerTotalHP;

        Transform parentTransform = transform.parent;
        spriteRenderer = parentTransform.GetComponent<SpriteRenderer>();

        UpdateUIText();
    }

    public void TakingDamage(float damage)
    {
        health -= damage;

        UpdateUIText();

        if (health <= 0)
        {
            // ANIMA��O DE MORTE
            Invoke(nameof(Die), 0.1f); // TEMPO QUE DURAR A ANIMA��O
        }
        GiveFeedback();
    }

    void UpdateUIText()
    {
        if (this.gameObject.transform.parent.name == "PlayerOne")
        {
            textOne.text = "Player 1:  " + health.ToString();
            oneHP = health;
        }

        else if (this.gameObject.transform.parent.name == "PlayerTwo")
        {
            textTwo.text = "Player 2:  " + health.ToString();
            twoHP = health;
        }
    }

    private void Die()
    {
        transform.parent.gameObject.SetActive(false);
    }

    void GiveFeedback()
    {
        spriteRenderer.color = Color.red;

        Invoke(nameof(ResetSpriteRender), 0.15f);
    }

    void ResetSpriteRender()
    {
        spriteRenderer.color = Color.white;
    }
}
