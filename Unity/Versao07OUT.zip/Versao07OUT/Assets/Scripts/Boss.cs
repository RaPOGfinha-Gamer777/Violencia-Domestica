using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class Boss : MonoBehaviour
{
    private EnemyStats enemyStats;
    public GameObject winScreen;
    public TextMeshProUGUI bossHPText;

    private void Start()
    {
        enemyStats = GameObject.FindAnyObjectByType<EnemyStats>();
    }

    private void Update()
    {
        if (gameObject.activeSelf)
        {
            bossHPText.text = "Boss: " + enemyStats.health;

            if (enemyStats.health <= 0)
            {
                winScreen.SetActive(true);
            }
        }
    }
}
