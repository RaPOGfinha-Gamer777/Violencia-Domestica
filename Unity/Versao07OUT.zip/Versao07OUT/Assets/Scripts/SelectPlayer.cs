using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelectPlayer : MonoBehaviour
{
    public GameObject selectionScreen;

    public void SelectOnePlayer()
    {
        Data.instance.enableOnePlayer = true;
        Data.instance.enableTwoPlayers = false;

        selectionScreen.SetActive(false);
    }
    public void SelectTwoPlayers()
    {
        Data.instance.enableOnePlayer = false;
        Data.instance.enableTwoPlayers = true;

        selectionScreen.SetActive(false);
    }
}
