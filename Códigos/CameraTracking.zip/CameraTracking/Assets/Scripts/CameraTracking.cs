using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraTracking : MonoBehaviour
{
    private Movement movement;

    private GameObject playerOne;
    private GameObject playerTwo;

    public bool playerOneInRight;
    public bool playerTwoInRight;

    private Camera mainCamera;

    private void Start()
    {
        movement = GameObject.FindAnyObjectByType<Movement>();
        playerOne = movement.playerOneBody.gameObject;
        playerTwo = movement.playerTwoBody.gameObject;

        mainCamera = Camera.main;
    }

    void Update()
    {
        Vector3 playerOneReference = mainCamera.WorldToScreenPoint(playerOne.transform.position);
        Vector3 playerTwoReference = mainCamera.WorldToScreenPoint(playerTwo.transform.position);

        float middle = Screen.width / 2;

        if (playerOneReference.x > middle) playerOneInRight = true;
        else playerOneInRight = false;

        if (playerTwoReference.x > middle) playerTwoInRight = true;
        else playerTwoInRight = false;
    }
}
