using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    [Header ("Player Stats")]
    public float playerHP;
    public float playerStrenght;
    public float playerSpeed;

    [Header("Enemies Stats")]
    public float regularHP;
    public float regularStrenght;
    public float regularSpeed;

    [Header("General Controller")]
    public int amountOfEnemies;
}
