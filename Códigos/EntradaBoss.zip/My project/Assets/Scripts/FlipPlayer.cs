using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlipPlayer : MonoBehaviour
{
    public GameObject playerOne;
    public GameObject playerTwo;

    private bool oneLookingRight = true;
    private bool twoLookingRight = true;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            if (oneLookingRight)
            {
                FlipOne();
            }
        }

        if (Input.GetKeyDown(KeyCode.D))
        {
            if (!oneLookingRight)
            {
                FlipOne();
            }
        }

        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            if (twoLookingRight)
            {
                FlipTwo();
            }
        }

        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            if (!twoLookingRight)
            {
                FlipTwo();
            }
        }
    }

    void FlipOne()
    {
        Vector3 escala = playerOne.transform.localScale;
        escala.x *= -1;
        playerOne.transform.localScale = escala;

        oneLookingRight = !oneLookingRight;
    }
    void FlipTwo()
    {
        Vector3 escala = playerTwo.transform.localScale;
        escala.x *= -1;
        playerTwo.transform.localScale = escala;

        twoLookingRight = !twoLookingRight;
    }
}
