using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerData : MonoBehaviour
{
    public GameObject playerOne;
    public GameObject playerTwo;
    
    private void OnEnable()
    {
        if (Data.instance.enableOnePlayer)
        {
            playerOne.SetActive(true);
            playerTwo.SetActive(false);
        }
        else if (Data.instance.enableTwoPlayers)
        {
            playerOne.SetActive(true);
            playerTwo.SetActive(true);
        }
    }
}
