using System.Collections;
using System.Collections.Generic;
using System.Net.Http.Headers;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public float playerPos;
    public float cameraPos;
    public bool cameraBool;

    public GameObject mainCamera;
    public Rigidbody2D playerOneBody;
    public Rigidbody2D playerTwoBody;

    private float closest;
    private float moveSpeed;
    private GameController gameController;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        moveSpeed = gameController.playerSpeed;
    }

    void Update()
    {
        MovePlayerOne();
        MovePlayerTwo();

        ComparePlayersPosition(playerOneBody.transform.position.x, playerTwoBody.transform.position.x);

        if (playerOneBody.transform.position.x > 0 && playerTwoBody.transform.position.x > 0) cameraBool = true;

        if (cameraBool) MoveCamera();
    }

    void MovePlayerOne()
    {
        float horizontalOne = Input.GetAxis("Horizontal_Player1");
        float verticalOne = Input.GetAxis("Vertical_Player1");

        playerOneBody.velocity = new Vector2(horizontalOne, verticalOne) * moveSpeed;

        playerPos = playerOneBody.transform.position.x;

        // ANIMA��O DE CORRER
    }
    void MovePlayerTwo()
    {
        float horizontalTwo = Input.GetAxis("Horizontal_Player2");
        float verticalTwo = Input.GetAxis("Vertical_Player2");

        playerTwoBody.velocity = new Vector2(horizontalTwo, verticalTwo) * moveSpeed;

        // ANIMA��O DE CORRER
    }

    float ComparePlayersPosition(float posOne, float posTwo)
    { 
        closest = Mathf.Min(posOne, posTwo);

        return closest;
    }

    void MoveCamera()
    {
        cameraPos = cameraPos + 1 * 0.01f;
        mainCamera.transform.position = new Vector3(cameraPos, 0, -10);

        if (cameraPos > closest) cameraBool = false;
    }
}
