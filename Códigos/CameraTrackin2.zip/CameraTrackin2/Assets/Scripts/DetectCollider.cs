using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DetectCollider : MonoBehaviour
{
    private GameController gameController;
    private float playerStrength;
    private string tagString = "Vazio";

    public List<GameObject> enemiesInRange;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        playerStrength = gameController.playerStrenght;
    }

    private void Update()
    {
        Attack();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        tagString = collision.gameObject.tag;

        if (tagString.Contains("Enemy"))
        {
            enemiesInRange.Add(collision.gameObject);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        tagString = "Vazio";
        enemiesInRange.Remove(collision.gameObject);
    }

    void Attack()
    {
        if (this.gameObject.name == "AttackColliderOne")
        {
            if (Input.GetKeyDown(KeyCode.R))
            {
                // ANIMA��O DE SOCO OU CHUTE

                Debug.Log("JOGADOR 1 ATACOU: " + tagString);

                foreach (GameObject enemy in enemiesInRange)
                {
                    EnemyStats scriptInimigo = enemy.GetComponent<EnemyStats>();

                    if (scriptInimigo != null)
                    {
                        scriptInimigo.TakingDamage(playerStrength);
                    }
                }
            }
        }

        else if (this.gameObject.name == "AttackColliderTwo")
        {
            if (Input.GetKeyDown(KeyCode.O))
            {
                // ANIMA��O DE SOCO OU CHUTE

                Debug.Log("JOGADOR 2 ATACOU: " + tagString);

                foreach (GameObject enemy in enemiesInRange)
                {
                    EnemyStats scriptInimigo = enemy.GetComponent<EnemyStats>();

                    if (scriptInimigo != null)
                    {
                        scriptInimigo.TakingDamage(playerStrength);
                    }
                }
            }
        }
    }
}
