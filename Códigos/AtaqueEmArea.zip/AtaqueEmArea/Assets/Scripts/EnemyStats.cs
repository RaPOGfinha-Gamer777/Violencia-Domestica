using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStats : MonoBehaviour
{

    public int health;
    public int strength;

    public void TakingDamage(int damage)
    {
        health -= damage;
        if (health <= 0)
        {
            // ANIMA��O DE MORTE
            Invoke(nameof(Die), 0.1f); // TEMPO QUE DURAR A ANIMA��O
        }
    }

    private void Die()
    {
        gameObject.transform.position = new Vector2(0, 10);
        Invoke(nameof(DestroyInstance), 0.2f);
    }

    private void DestroyInstance()
    {
        Destroy(gameObject);
    }
}
