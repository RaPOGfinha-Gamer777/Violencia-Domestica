using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Unity.VisualScripting;

public class PlayerHP : MonoBehaviour
{
    public float health;
    private GameController gameController;

    public TextMeshProUGUI textOne;
    public TextMeshProUGUI textTwo;

    void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        health = gameController.playerTotalHP;

        UpdateUIText();
    }

    public void TakingDamage(float damage)
    {
        health -= damage;

        UpdateUIText();

        if (health <= 0)
        {
            // ANIMA��O DE MORTE
            Invoke(nameof(Die), 0.1f); // TEMPO QUE DURAR A ANIMA��O
        }
    }

    void UpdateUIText()
    {
        if (this.gameObject.transform.parent.name == "PlayerOne")
        {
            textOne.text = "Player 1:  " + health.ToString();
        }

        else if (this.gameObject.transform.parent.name == "PlayerTwo")
        {
            textTwo.text = "Player 2:  " + health.ToString();
        }
    }

    private void Die()
    {
        transform.parent.gameObject.SetActive(false);
    }
}
