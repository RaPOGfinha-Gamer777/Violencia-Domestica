using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawn : MonoBehaviour
{
    public GameObject enemyPrefab;

    public GameObject spawnPoint;
    private int amount;
    public float spawnRadius = 0.5f;

    private GameController gameController;

    void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        amount = gameController.amountOfEnemies;

        SpawnEnemies();
    }

    void SpawnEnemies()
    {
        for (int i = 0; i < amount; i++)
        {
            Vector2 pontoAleatorio = Random.insideUnitCircle * spawnRadius;
            Vector3 novaPosicao = new Vector3(pontoAleatorio.x, pontoAleatorio.y, 0) + spawnPoint.transform.position;

            GameObject newEnemy = Instantiate(enemyPrefab, novaPosicao, Quaternion.identity);

            EnemyStats stats = newEnemy.GetComponent<EnemyStats>();
            stats.health = 5;
        }
    }
}
