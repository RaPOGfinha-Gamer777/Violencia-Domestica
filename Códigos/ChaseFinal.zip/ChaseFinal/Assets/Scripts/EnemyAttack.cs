using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class EnemyAttack : MonoBehaviour
{
    private float strenght;
    private GameController gameController;

    public bool moveBool = true;
    public GameObject attackTarget;
    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        strenght = gameController.regularStrenght;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "HitBox")
        {
            moveBool = false;
            attackTarget = collision.gameObject;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        moveBool = true;
        attackTarget = null;
    }
}
