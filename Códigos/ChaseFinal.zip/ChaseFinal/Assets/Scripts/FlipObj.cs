using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlipObj : MonoBehaviour
{
    private float previousPosX;  
    private bool isLookingRight = true;

    void Start()
    {
        previousPosX = transform.position.x;
    }

    void Update()
    {
        float currentPosX = transform.position.x;

        if (currentPosX > previousPosX && !isLookingRight)
        {
            FlipSprite();
        }
        else if (currentPosX < previousPosX && isLookingRight)
        {
            FlipSprite();
        }
        previousPosX = currentPosX;
    }

    void FlipSprite()
    {
        Vector3 scale = transform.localScale;
        scale.x *= -1;  
        transform.localScale = scale;

        isLookingRight = !isLookingRight;
    }
}
