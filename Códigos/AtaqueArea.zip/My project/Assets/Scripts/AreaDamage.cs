using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AreaDamage : MonoBehaviour
{
    public float areaAttackTimer;
    private bool areaAttackBool = true;

    

    private BossMovement bossMovement;

    private void Start()
    {
        bossMovement = GameObject.FindAnyObjectByType<BossMovement>();
    }

    private void Update()
    {
        if (areaAttackBool)
        {
            areaAttackTimer += Time.deltaTime;

            if (areaAttackTimer > 7)
            {
                bossMovement.moveBossBool = false;
                areaAttackBool = false;
                areaAttackTimer = 0;

                Invoke(nameof(AttackPlayersArround), 2);
            }
        }
    }

    void AttackPlayersArround()
    {
        
    }
}
