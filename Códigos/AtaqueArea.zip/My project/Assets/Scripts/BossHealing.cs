using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossHealing : MonoBehaviour
{
    private EnemyStats enemyStats;
    private BossMovement bossMovement;

    private SpriteRenderer spriteRenderer;

    private float healTimer = 0;

    private void Start()
    {
        enemyStats = GameObject.FindAnyObjectByType<EnemyStats>();
        bossMovement = GameObject.FindAnyObjectByType<BossMovement>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        if (enemyStats.health <= 40 && enemyStats.health >= 15)
        {
            CheckBossHP();
        }
    }

    void CheckBossHP()
    {
        healTimer += Time.deltaTime;

        if (healTimer > 3)
        {
            healTimer = 0;

            int rng = Random.Range(0, 3);
            
            if (rng == 0)
            {
                bossMovement.moveBossBool = false;
                spriteRenderer.color = Color.blue;

                Invoke(nameof(HealBoss), 2);
            }
        }
    }

    void HealBoss()
    {
        enemyStats.health += 10;
        bossMovement.moveBossBool = true;
        spriteRenderer.color = Color.white;
    }
}
