using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    private GameController gameController;

    private float enemySpeed;

    public GameObject enemyObj;
    public GameObject target;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        enemySpeed = gameController.regularSpeed;
    }

    private void Update()
    {
        if (target != null)
        {
            Transform destination = target.transform;
            Vector2 direction = destination.position - transform.position;

            direction.Normalize();

            enemyObj.transform.position = transform.position + (Vector3)direction * enemySpeed * Time.deltaTime;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            target = collision.gameObject;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag != "Player")
        {
            target = null;
        }
    }
}
