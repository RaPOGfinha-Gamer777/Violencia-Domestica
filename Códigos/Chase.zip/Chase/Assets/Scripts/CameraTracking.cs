using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraTracking : MonoBehaviour
{
    private Movement movement;

    private GameObject playerOne;
    private GameObject playerTwo;

    public bool playerOneInRight;
    public bool playerTwoInRight;

    private Camera mainCamera;

    private float closest;
    private float furthest;

    private GameObject soloPlayer;

    public bool canMoveLeft;
    public bool canMoveRight = true;

    private void Start()
    {
        movement = GameObject.FindAnyObjectByType<Movement>();
        playerOne = movement.playerOneBody.gameObject;
        playerTwo = movement.playerTwoBody.gameObject;

        mainCamera = Camera.main;
    }

    void Update()
    {
        if (playerOne.activeSelf && playerTwo.activeSelf)
        {
            CalculateWithBothPlayers();
        }
        else
        {
            CalculateWithSoloPlayer();
        }
    }

    void CalculateWithBothPlayers()
    {
        CheckPlayersPosition();
        CheckCameraPosition();

        ComparePlayersPosition(playerOne.transform.position.x, playerTwo.transform.position.x);

        if (playerOneInRight && playerTwoInRight && canMoveRight)
        {
            MoveCameraRight();
        }

        else if (!playerOneInRight && !playerTwoInRight && canMoveLeft)
        {
            MoveCameraLeft();
        }
    }

    void CalculateWithSoloPlayer()
    {
        if (playerOne.activeSelf) soloPlayer = playerOne;
        else soloPlayer = playerTwo;

        Vector3 soloPlayerReference = mainCamera.WorldToScreenPoint(soloPlayer.transform.position);
        float middle = Screen.width / 2;

        CheckCameraPosition();

        if (!canMoveLeft && soloPlayerReference.x > middle || canMoveLeft && canMoveRight || !canMoveRight && soloPlayerReference.x < middle)
        {
            mainCamera.transform.position = new Vector3(soloPlayer.transform.position.x, 0, -10);
        }
    }

    void CheckPlayersPosition()
    {
        Vector3 playerOneReference = mainCamera.WorldToScreenPoint(playerOne.transform.position);
        Vector3 playerTwoReference = mainCamera.WorldToScreenPoint(playerTwo.transform.position);

        float middle = Screen.width / 2;

        if (playerOneReference.x > middle) playerOneInRight = true;
        else playerOneInRight = false;

        if (playerTwoReference.x > middle) playerTwoInRight = true;
        else playerTwoInRight = false;
    }

    void CheckCameraPosition()
    {
        if (mainCamera.transform.position.x <= 0) canMoveLeft = false;
        else canMoveLeft = true;

        if (mainCamera.transform.position.x >= 13.8) canMoveRight = false;
        else canMoveRight = true;
    }

    void ComparePlayersPosition(float posOne, float posTwo)
    {
        closest = Mathf.Min(posOne, posTwo);
        furthest = Mathf.Max(posOne, posTwo);
    }

    void MoveCameraRight()
    {
        mainCamera.transform.position = new Vector3(closest, 0, -10);
    }

    void MoveCameraLeft()
    {
        mainCamera.transform.position = new Vector3(furthest, 0, -10);
    }
}
