using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
//using UnityEditor.Build.Content;

public class SelecaoPersonagem : MonoBehaviour
{
    public Image dianaImage, auroraImage;
    private Color defaultColor;
    [SerializeField] private string proximaCena;
    private int characterIndex;
    // Start is called before the first frame update
    void Start()
    {
        characterIndex = 1;
        defaultColor = auroraImage.color;
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetAxis("UIHORIZONTAL") < 0)
        {
            characterIndex = 1;
        }
        else if (Input.GetAxis("UIHORIZONTAL") > 0)
        {
            characterIndex = 2;
        }


        if (Input.GetKeyUp(KeyCode.A))
        {
            characterIndex = 1;
        }
        else if (Input.GetKeyUp(KeyCode.D))
        {
            characterIndex = 2;
        }

        if (characterIndex == 1)
        {
            dianaImage.color = Color.red;
            auroraImage.color = defaultColor;
        }
        else if (characterIndex == 2)
        {
            dianaImage.color = defaultColor;
            auroraImage.color = Color.blue;
        }

        if (Input.GetButtonDown("UIVERDE") || Input.GetKeyDown(KeyCode.R) || Input.GetKeyDown(KeyCode.O))
        {
            Time.timeScale = 1;
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }
}
