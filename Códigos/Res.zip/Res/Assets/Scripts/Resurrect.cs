using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Resurrect : MonoBehaviour
{
    private GameController gameController;

    private bool resBool;
    private float resTimerMultiplier = 1;
    private float resBarX;

    private float timeToRes;
    private float timeProportion;

    GameObject timerBar;
    public GameObject nearestPlayer;

    private void Start()
    {
        gameController = GameObject.FindAnyObjectByType<GameController>();
        timeToRes = gameController.resurrectTimer;

        resBarX = timerBar.transform.localScale.x;
        timeProportion = resBarX/timeToRes;
    }

    private void Update()
    {
        if (resBool)
        {
            resBarX -= Time.deltaTime * resTimerMultiplier * timeProportion;

            timerBar.transform.localScale = new Vector2(resBarX, timerBar.transform.localScale.y);

            if (resBarX < 0)
            {
                Die();
            }
        }
    }

    private void OnEnable()
    {
        resBool = true;
        timerBar = transform.Find("TimerSprite").gameObject;
    }

    void Die()
    {
        Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "HitBox")
        {
            nearestPlayer = collision.gameObject;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "HitBox")
        {
            nearestPlayer = null;
        }
    }
}
