using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WinCondition : MonoBehaviour
{
    public GameObject winScreen;
    public GameObject defeatScreen;

    public GameObject playerOne;
    public GameObject playerTwo;

    private void Update()
    {
        CheckWinCondition();
        CheckDefeatCondition();

        ReturnToMenu();
    }

    void CheckWinCondition()
    {
        if (!playerOne.activeSelf && !playerTwo.activeSelf)
        {
            //Time.timeScale = 0;
            defeatScreen.SetActive(true);
        }
    }

    void CheckDefeatCondition()
    {
        GameObject enemy = GameObject.FindWithTag("RegularEnemy");
        
        if (enemy == null)
        {
            Time.timeScale = 0;
            winScreen.SetActive(true);
        }
    }

    void ReturnToMenu()
    {
        if (winScreen.activeSelf || defeatScreen.activeSelf)
        {
            if (Input.anyKeyDown)
            {
                SceneManager.LoadScene("MenuPrototipo");
            }
        }
    }
}
