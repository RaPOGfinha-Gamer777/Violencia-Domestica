using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EnterBossFight : MonoBehaviour
{
    private WinCondition winCondition;
    private bool canEnterBoss;

    private void Start()
    {
        winCondition = GameObject.FindAnyObjectByType<WinCondition>();
    }

    private void Update()
    {
        if (canEnterBoss && winCondition.bossEntranceBool)
        {
            if (Input.anyKeyDown)
            {
                SceneManager.LoadScene("FirstBoss");
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "BossEntrance")
        {
            canEnterBoss = true;
        }
    }


    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "BossEntrance")
        {
            canEnterBoss = false;
        }
    }
}
