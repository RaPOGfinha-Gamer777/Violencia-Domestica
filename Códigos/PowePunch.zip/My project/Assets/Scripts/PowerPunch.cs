using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerPunch : MonoBehaviour
{
    private EnemyAttack enemyAttack;

    public float powerPunchTimer;
    public bool powerPunchBool;

    private void Start()
    {
        enemyAttack = GameObject.FindAnyObjectByType<EnemyAttack>();
    }

    private void Update()
    {
        if (enemyAttack.moveBool == false)
        {
            powerPunchTimer += Time.deltaTime;

            if (powerPunchTimer > 5)
            {
                powerPunchTimer = 0;     
                powerPunchBool = true;
            }
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        powerPunchTimer = 0;
        powerPunchBool= false;
    }
}
