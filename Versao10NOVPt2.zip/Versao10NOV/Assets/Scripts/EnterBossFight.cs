using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class EnterBossFight : MonoBehaviour
{
    private WinCondition winCondition;
    private bool canEnterBoss;

    public GameObject playerOne;
    public GameObject playerTwo;

    public GameObject boss;
    public GameObject bossUI;

    public GameObject mainCamera;
    public GameObject bossCamera;

    private void Start()
    {
        winCondition = GameObject.FindAnyObjectByType<WinCondition>();
    }

    private void Update()
    {
        if (canEnterBoss && winCondition.bossEntranceBool)
        {
            if (Input.anyKeyDown)
            {
                if (playerOne.activeSelf) playerOne.transform.position = new Vector3(126, -1.7f, 0);
                
                if (playerTwo.activeSelf) playerTwo.transform.position = new Vector3(127.6f, -2.7f, 0);

                boss.SetActive(true);
                bossUI.SetActive(true);

                mainCamera.SetActive(false);
                bossCamera.SetActive(true);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "BossEntrance")
        {
            canEnterBoss = true;
        }
    }


    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "BossEntrance")
        {
            canEnterBoss = false;
        }
    }
}
