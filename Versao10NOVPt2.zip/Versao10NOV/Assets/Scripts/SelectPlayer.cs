using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SelectPlayer : MonoBehaviour
{
    //public GameObject selectionScreen;
    //public GameObject menuObj;

    public void SelectOnePlayer()
    {
        Data.instance.enableOnePlayer = true;
        Data.instance.enableTwoPlayers = false;

        SceneManager.LoadScene("SampleScene");

        //selectionScreen.SetActive(false);
        //menuObj.SetActive(true);
    }
    public void SelectTwoPlayers()
    {
        Data.instance.enableOnePlayer = false;
        Data.instance.enableTwoPlayers = true;

        SceneManager.LoadScene("SampleScene");

        //selectionScreen.SetActive(false);
        //menuObj.SetActive(true);
    }
}
