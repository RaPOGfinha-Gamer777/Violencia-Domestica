using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class PlayerData : MonoBehaviour
{
    public GameObject playerOne;
    public GameObject playerTwo;
    
    private void OnEnable()
    {
        if (Data.instance.enableOnePlayer)
        {
            playerOne.SetActive(true);
            playerTwo.SetActive(false);

            GameController gameController = FindAnyObjectByType<GameController>();
            gameController.amountOfEnemies = 1;
            gameController.playerTotalHP = 20;
        }
        else if (Data.instance.enableTwoPlayers)
        {
            playerOne.SetActive(true);
            playerTwo.SetActive(true);

            GameController gameController = FindAnyObjectByType<GameController>();
            gameController.amountOfEnemies = 2;
            gameController.playerTotalHP = 10;
        }
    }
}
