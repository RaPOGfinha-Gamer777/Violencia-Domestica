using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResurrectMethods : MonoBehaviour
{
    private PlayerHP playerHP;

    public float resTimerMultiplier;

    public GameObject playerOne;
    public GameObject playerTwo;

    public AudioSource audioSource;
    public AudioClip deathAudio;
    public AudioClip resAudio;

    private void Start()
    {
        playerHP = GameObject.FindAnyObjectByType<PlayerHP>();
    }

    public void ResPlayerOne()
    {
        playerOne.SetActive(true);

        audioSource.clip = resAudio;
        audioSource.Play();
    }

    public void ResPlayerTwo()
    {
        playerTwo.SetActive(true);

        audioSource.clip = resAudio;
        audioSource.Play();
    }

    public void PlayDeathAudio()
    {
        audioSource.clip = deathAudio;
        audioSource.Play();
    }
}
